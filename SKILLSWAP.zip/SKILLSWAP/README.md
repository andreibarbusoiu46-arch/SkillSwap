# SkillSwap — Full-Stack

Platformă web de schimb de aptitudini între utilizatori (Spring Boot + H2 + SPA).

## Cerințe

- Java 17+
- Maven 3.8+

## Rulare

```bash
cd SKILLSWAP
mvn spring-boot:run
```

Deschide în browser: [http://localhost:8080](http://localhost:8080)

Consolă H2 (opțional): [http://localhost:8080/h2-console](http://localhost:8080/h2-console) — JDBC URL: `jdbc:h2:mem:skillswap`, user: `sa`, parolă goală.

## Conturi demo

| Rol    | Email                 | Parolă   |
|--------|-----------------------|----------|
| Membru | alex@example.com      | pass123  |
| Admin  | admin@skillswap.ro    | admin123 |

## Structură

```
src/main/java/com/skillswap/
  model/          — AppUser, Skill, SwapRequest, MeetingSession (+ Conversation, Message)
  repository/     — Spring Data JPA
  service/        — logică business
  controller/     — REST API /api/*
  config/         — seed data, sesiune, web
src/main/resources/
  application.properties
  static/index.html
```

## API principal

| Metodă | Endpoint | Descriere |
|--------|----------|-----------|
| POST | `/api/auth/login` | Autentificare |
| POST | `/api/auth/register` | Înregistrare |
| GET | `/api/search?q=` | Căutare parteneri (indexată, <2s) |
| PUT | `/api/skills/me` | Aptitudini oferite/căutate |
| POST | `/api/swap-requests` | Cerere schimb |
| GET | `/api/conversations` | Mesaje |
| POST | `/api/conversations/meetings` | Programare ședință |
