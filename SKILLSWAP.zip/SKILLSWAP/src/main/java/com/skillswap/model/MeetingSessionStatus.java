package com.skillswap.model;

public enum MeetingSessionStatus {
    IN_ASTEPTARE,
    PROGRAMATA,
    ANULATA,
    REPROGRAMARE
}
