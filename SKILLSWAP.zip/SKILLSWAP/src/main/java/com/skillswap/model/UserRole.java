package com.skillswap.model;

public enum UserRole {
    MEMBER,
    ADMIN
}
