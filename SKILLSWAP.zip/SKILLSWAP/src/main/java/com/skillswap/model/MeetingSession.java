package com.skillswap.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "meeting_sessions", indexes = {
        @Index(name = "idx_meeting_conversation", columnList = "conversation_id"),
        @Index(name = "idx_meeting_status", columnList = "status")
})
public class MeetingSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "conversation_id", nullable = false, unique = true)
    private Conversation conversation;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "initiator_id", nullable = false)
    private AppUser initiator;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "guest_id", nullable = false)
    private AppUser guest;

    @NotNull
    @Column(nullable = false)
    private LocalDate sessionDate;

    @NotNull
    @Column(nullable = false)
    private LocalTime sessionTime;

    @NotBlank
    @Size(max = 500)
    @Column(nullable = false, length = 500)
    private String location;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MeetingSessionStatus status = MeetingSessionStatus.IN_ASTEPTARE;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Conversation getConversation() {
        return conversation;
    }

    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
    }

    public AppUser getInitiator() {
        return initiator;
    }

    public void setInitiator(AppUser initiator) {
        this.initiator = initiator;
    }

    public AppUser getGuest() {
        return guest;
    }

    public void setGuest(AppUser guest) {
        this.guest = guest;
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public void setSessionDate(LocalDate sessionDate) {
        this.sessionDate = sessionDate;
    }

    public LocalTime getSessionTime() {
        return sessionTime;
    }

    public void setSessionTime(LocalTime sessionTime) {
        this.sessionTime = sessionTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public MeetingSessionStatus getStatus() {
        return status;
    }

    public void setStatus(MeetingSessionStatus status) {
        this.status = status;
    }
}
