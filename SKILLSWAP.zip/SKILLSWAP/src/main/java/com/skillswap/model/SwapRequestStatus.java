package com.skillswap.model;

public enum SwapRequestStatus {
    Pending,
    Accepted,
    Rejected
}
