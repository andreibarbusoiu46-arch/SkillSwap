package com.skillswap.model;

public enum SkillType {
    OFFERED,
    WANTED
}
