package com.skillswap.controller;

import com.skillswap.dto.UserProfileDto;
import com.skillswap.service.AuthService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final AuthService authService;

    public UserController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping
    public List<UserProfileDto> listMembers() {
        return authService.listMembers();
    }

    @GetMapping("/{id}")
    public UserProfileDto getUser(@PathVariable Long id) {
        return authService.getUserById(id);
    }
}
