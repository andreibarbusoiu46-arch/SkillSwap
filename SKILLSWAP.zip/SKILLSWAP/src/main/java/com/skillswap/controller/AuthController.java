package com.skillswap.controller;

import com.skillswap.dto.*;
import com.skillswap.service.AuthService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public UserProfileDto login(@Valid @RequestBody LoginRequest request, HttpSession session) {
        return authService.login(request, session);
    }

    @PostMapping("/register")
    public UserProfileDto register(@Valid @RequestBody RegisterRequest request, HttpSession session) {
        return authService.register(request, session);
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, String>> logout(HttpSession session) {
        authService.logout(session);
        return ResponseEntity.ok(Map.of("message", "Deconectat."));
    }

    @GetMapping("/me")
    public ResponseEntity<UserProfileDto> me(HttpSession session) {
        if (session == null || session.getAttribute(com.skillswap.config.SessionAuth.SESSION_USER_ID) == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(authService.currentUser());
    }
}
