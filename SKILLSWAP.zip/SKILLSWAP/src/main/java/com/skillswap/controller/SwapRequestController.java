package com.skillswap.controller;

import com.skillswap.dto.SwapRequestCreate;
import com.skillswap.dto.SwapRequestDto;
import com.skillswap.dto.SwapRequestRespond;
import com.skillswap.service.SwapRequestService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/swap-requests")
public class SwapRequestController {

    private final SwapRequestService swapRequestService;

    public SwapRequestController(SwapRequestService swapRequestService) {
        this.swapRequestService = swapRequestService;
    }

    @PostMapping
    public SwapRequestDto create(@Valid @RequestBody SwapRequestCreate request) {
        return swapRequestService.create(request);
    }

    @PatchMapping("/{id}")
    public SwapRequestDto respond(@PathVariable Long id, @Valid @RequestBody SwapRequestRespond request) {
        return swapRequestService.respond(id, request);
    }

    @GetMapping("/pending")
    public List<SwapRequestDto> pending() {
        return swapRequestService.pendingForMe();
    }

    @GetMapping("/between")
    public ResponseEntity<SwapRequestDto> between(@RequestParam Long fromId, @RequestParam Long toId) {
        SwapRequestDto dto = swapRequestService.findBetween(fromId, toId);
        return dto != null ? ResponseEntity.ok(dto) : ResponseEntity.noContent().build();
    }
}
