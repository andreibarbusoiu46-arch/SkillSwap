package com.skillswap.controller;

import com.skillswap.dto.ReportDto;
import com.skillswap.dto.SwapRequestDto;
import com.skillswap.dto.UserProfileDto;
import com.skillswap.service.AdminService;
import com.skillswap.service.SwapRequestService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;
    private final SwapRequestService swapRequestService;

    public AdminController(AdminService adminService, SwapRequestService swapRequestService) {
        this.adminService = adminService;
        this.swapRequestService = swapRequestService;
    }

    @GetMapping("/users")
    public List<UserProfileDto> users() {
        return adminService.listUsers();
    }

    @PatchMapping("/users/{id}/block")
    public UserProfileDto toggleBlock(@PathVariable Long id) {
        return adminService.toggleBlock(id);
    }

    @GetMapping("/swap-requests")
    public List<SwapRequestDto> swapRequests() {
        return swapRequestService.allForAdmin();
    }

    @GetMapping("/reports")
    public List<ReportDto> reports() {
        return adminService.listReports();
    }

    @PatchMapping("/reports/{id}/resolve")
    public ReportDto resolve(@PathVariable Long id) {
        return adminService.resolveReport(id);
    }
}
