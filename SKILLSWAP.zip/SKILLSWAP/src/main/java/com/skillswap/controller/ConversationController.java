package com.skillswap.controller;

import com.skillswap.dto.*;
import com.skillswap.service.ConversationService;
import com.skillswap.service.MeetingSessionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/conversations")
public class ConversationController {

    private final ConversationService conversationService;
    private final MeetingSessionService meetingSessionService;

    public ConversationController(
            ConversationService conversationService,
            MeetingSessionService meetingSessionService) {
        this.conversationService = conversationService;
        this.meetingSessionService = meetingSessionService;
    }

    @GetMapping
    public List<ConversationDto> list() {
        return conversationService.myConversations();
    }

    @GetMapping("/{id}")
    public ConversationDto get(@PathVariable Long id) {
        return conversationService.getConversation(id);
    }

    @PostMapping("/{id}/messages")
    public MessageDto sendMessage(@PathVariable Long id, @Valid @RequestBody MessageCreate request) {
        return conversationService.sendMessage(id, request);
    }

    @PostMapping("/meetings")
    public MeetingSessionDto schedule(@Valid @RequestBody MeetingSessionRequest request) {
        return meetingSessionService.schedule(request);
    }

    @PatchMapping("/meetings/{id}")
    public MeetingSessionDto respondMeeting(@PathVariable Long id, @Valid @RequestBody MeetingSessionRespond request) {
        return meetingSessionService.respond(id, request);
    }
}
