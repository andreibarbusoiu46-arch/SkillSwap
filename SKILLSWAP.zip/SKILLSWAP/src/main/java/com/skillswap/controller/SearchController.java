package com.skillswap.controller;

import com.skillswap.dto.SearchResponse;
import com.skillswap.service.SearchService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    private final SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping
    public SearchResponse search(@RequestParam(required = false, defaultValue = "") String q) {
        return searchService.search(q);
    }
}
