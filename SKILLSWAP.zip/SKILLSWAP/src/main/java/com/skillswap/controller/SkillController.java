package com.skillswap.controller;

import com.skillswap.dto.SkillBrowseDto;
import com.skillswap.dto.SkillUpdateRequest;
import com.skillswap.dto.UserProfileDto;
import com.skillswap.service.SkillService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/skills")
public class SkillController {

    private final SkillService skillService;

    public SkillController(SkillService skillService) {
        this.skillService = skillService;
    }

    @GetMapping("/browse")
    public List<SkillBrowseDto> browse() {
        return skillService.browseOfferedSkills();
    }

    @PutMapping("/me")
    public UserProfileDto updateMySkills(@Valid @RequestBody SkillUpdateRequest request) {
        return skillService.updateMySkills(request);
    }
}
