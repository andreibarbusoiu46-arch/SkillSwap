package com.skillswap.dto;

import com.skillswap.model.SwapRequestStatus;
import jakarta.validation.constraints.NotNull;

public record SwapRequestRespond(
        @NotNull SwapRequestStatus status
) {}
