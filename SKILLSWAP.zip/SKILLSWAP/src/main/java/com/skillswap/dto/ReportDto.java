package com.skillswap.dto;

import com.skillswap.model.Report;

public record ReportDto(Long id, Long rerId, Long redId, String reason, String status) {
    public static ReportDto from(Report r) {
        return new ReportDto(
                r.getId(),
                r.getReporter().getId(),
                r.getReported().getId(),
                r.getReason(),
                r.getStatus()
        );
    }
}
