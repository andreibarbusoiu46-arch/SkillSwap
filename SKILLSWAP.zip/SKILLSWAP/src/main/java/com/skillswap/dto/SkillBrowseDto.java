package com.skillswap.dto;

public record SkillBrowseDto(String cat, String desc, UserProfileDto usr) {}
