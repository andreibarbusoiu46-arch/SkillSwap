package com.skillswap.dto;

import jakarta.validation.constraints.Size;

public record SkillUpdateRequest(
        @Size(max = 80) String offeredCategory,
        @Size(max = 500) String offeredDescription,
        @Size(max = 80) String wantedCategory
) {}
