package com.skillswap.dto;

import com.skillswap.model.AppUser;
import com.skillswap.model.SwapRequest;

public record SwapRequestDto(
        Long id,
        Long fId,
        Long tId,
        String msg,
        String status,
        String dt,
        Long conversationId,
        String fromName,
        String fromAv,
        String fromCol
) {
    public static SwapRequestDto from(SwapRequest r) {
        AppUser from = r.getFromUser();
        return new SwapRequestDto(
                r.getId(),
                from.getId(),
                r.getToUser().getId(),
                r.getMessage(),
                r.getStatus().name(),
                r.getRequestDate().toString(),
                r.getConversation() != null ? r.getConversation().getId() : null,
                from.getDisplayName(),
                from.getAvatarInitials(),
                from.getAvatarColor()
        );
    }
}
