package com.skillswap.dto;

import com.skillswap.model.MeetingSessionStatus;
import jakarta.validation.constraints.NotNull;

public record MeetingSessionRespond(
        @NotNull MeetingSessionStatus status
) {}
