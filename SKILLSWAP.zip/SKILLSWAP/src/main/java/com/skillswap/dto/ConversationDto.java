package com.skillswap.dto;

import com.skillswap.model.AppUser;
import com.skillswap.model.Conversation;
import com.skillswap.model.MeetingSession;
import com.skillswap.model.Message;

import java.util.List;
import java.util.stream.Collectors;

public record ConversationDto(
        Long id,
        List<Long> pts,
        List<MessageDto> msgs,
        Long rId,
        String swapStatus,
        MeetingSessionDto session
) {
    public static ConversationDto from(Conversation c, List<Message> messages, MeetingSession session) {
        return new ConversationDto(
                c.getId(),
                c.getParticipants().stream().map(AppUser::getId).collect(Collectors.toList()),
                messages.stream().map(MessageDto::from).collect(Collectors.toList()),
                c.getSwapRequest() != null ? c.getSwapRequest().getId() : null,
                c.getSwapRequest() != null ? c.getSwapRequest().getStatus().name() : null,
                session != null ? MeetingSessionDto.from(session) : null
        );
    }
}
