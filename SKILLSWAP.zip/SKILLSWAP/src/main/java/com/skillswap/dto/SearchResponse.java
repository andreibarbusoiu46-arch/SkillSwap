package com.skillswap.dto;

import java.util.List;

public record SearchResponse(List<UserProfileDto> results, long elapsedMs) {}
