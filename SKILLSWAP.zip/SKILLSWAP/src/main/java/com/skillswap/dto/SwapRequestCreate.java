package com.skillswap.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SwapRequestCreate(
        @NotNull Long toUserId,
        @NotBlank @Size(max = 1000) String message
) {}
