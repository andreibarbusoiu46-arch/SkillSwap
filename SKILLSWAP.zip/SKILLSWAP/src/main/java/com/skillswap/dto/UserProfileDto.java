package com.skillswap.dto;

import com.skillswap.model.AppUser;
import com.skillswap.model.SkillType;
import com.skillswap.model.UserRole;

import java.util.List;
import java.util.stream.Collectors;

public record UserProfileDto(
        Long id,
        String un,
        String email,
        String role,
        boolean confirmed,
        boolean blocked,
        String name,
        String bio,
        List<SkillDto> offered,
        List<SkillDto> wanted,
        String av,
        String col
) {
    public static UserProfileDto from(AppUser u) {
        List<SkillDto> offered = u.getSkills().stream()
                .filter(s -> s.getSkillType() == SkillType.OFFERED)
                .map(SkillDto::from)
                .collect(Collectors.toList());
        List<SkillDto> wanted = u.getSkills().stream()
                .filter(s -> s.getSkillType() == SkillType.WANTED)
                .map(SkillDto::from)
                .collect(Collectors.toList());
        return new UserProfileDto(
                u.getId(),
                u.getUsername(),
                u.getEmail(),
                u.getRole() == UserRole.ADMIN ? "admin" : "member",
                u.isConfirmed(),
                u.isBlocked(),
                u.getDisplayName(),
                u.getBio(),
                offered,
                wanted,
                u.getAvatarInitials(),
                u.getAvatarColor()
        );
    }
}
