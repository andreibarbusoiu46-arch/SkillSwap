package com.skillswap.dto;

import com.skillswap.model.Message;

import java.time.format.DateTimeFormatter;

public record MessageDto(Long f, String t, String ts) {
    public static MessageDto from(Message m) {
        return new MessageDto(
                m.getSender().getId(),
                m.getText(),
                m.getSentAt().format(DateTimeFormatter.ofPattern("HH:mm"))
        );
    }
}
