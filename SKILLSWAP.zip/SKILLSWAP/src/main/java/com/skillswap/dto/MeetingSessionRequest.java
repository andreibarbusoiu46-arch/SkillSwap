package com.skillswap.dto;

import com.skillswap.model.MeetingSessionStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.time.LocalTime;

public record MeetingSessionRequest(
        @NotNull Long conversationId,
        @NotNull LocalDate date,
        @NotNull LocalTime time,
        @NotBlank @Size(max = 500) String location
) {}
