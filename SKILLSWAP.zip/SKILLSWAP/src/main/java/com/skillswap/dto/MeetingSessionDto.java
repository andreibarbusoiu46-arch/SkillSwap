package com.skillswap.dto;

import com.skillswap.model.MeetingSession;
import com.skillswap.model.MeetingSessionStatus;

import java.time.format.DateTimeFormatter;

public record MeetingSessionDto(
        Long id,
        Long cId,
        Long iId,
        Long gId,
        String date,
        String time,
        String loc,
        String status
) {
    public static MeetingSessionDto from(MeetingSession s) {
        return new MeetingSessionDto(
                s.getId(),
                s.getConversation().getId(),
                s.getInitiator().getId(),
                s.getGuest().getId(),
                s.getSessionDate().toString(),
                s.getSessionTime().format(DateTimeFormatter.ofPattern("HH:mm")),
                s.getLocation(),
                mapStatus(s.getStatus())
        );
    }

    private static String mapStatus(MeetingSessionStatus status) {
        return switch (status) {
            case IN_ASTEPTARE -> "În așteptare";
            case PROGRAMATA -> "Programată";
            case ANULATA -> "Anulată";
            case REPROGRAMARE -> "Reprogramare";
        };
    }
}
