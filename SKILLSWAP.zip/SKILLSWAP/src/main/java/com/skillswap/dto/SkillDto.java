package com.skillswap.dto;

import com.skillswap.model.Skill;

public record SkillDto(String cat, String desc) {
    public static SkillDto from(Skill s) {
        return new SkillDto(s.getCategory(), s.getDescription() != null ? s.getDescription() : "");
    }
}
