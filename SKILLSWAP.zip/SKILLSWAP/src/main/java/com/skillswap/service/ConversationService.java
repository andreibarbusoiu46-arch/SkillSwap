package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.*;
import com.skillswap.exception.ApiException;
import com.skillswap.model.*;
import com.skillswap.repository.ConversationRepository;
import com.skillswap.repository.MeetingSessionRepository;
import com.skillswap.repository.MessageRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ConversationService {

    private final ConversationRepository conversationRepository;
    private final MessageRepository messageRepository;
    private final MeetingSessionRepository meetingSessionRepository;
    private final SessionAuth sessionAuth;

    public ConversationService(
            ConversationRepository conversationRepository,
            MessageRepository messageRepository,
            MeetingSessionRepository meetingSessionRepository,
            SessionAuth sessionAuth) {
        this.conversationRepository = conversationRepository;
        this.messageRepository = messageRepository;
        this.meetingSessionRepository = meetingSessionRepository;
        this.sessionAuth = sessionAuth;
    }

    private void assertParticipant(Conversation conv, Long userId) {
        boolean member = conv.getParticipants().stream().anyMatch(p -> p.getId().equals(userId));
        if (!member) {
            throw new ApiException(403, "Nu ai acces la această conversație.");
        }
    }

    @Transactional(readOnly = true)
    public List<ConversationDto> myConversations() {
        AppUser user = sessionAuth.requireUser();
        return conversationRepository.findByParticipantId(user.getId()).stream()
                .map(c -> toDto(c))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ConversationDto getConversation(Long id) {
        AppUser user = sessionAuth.requireUser();
        Conversation conv = conversationRepository.findById(id)
                .orElseThrow(() -> new ApiException(404, "Conversație negăsită."));
        assertParticipant(conv, user.getId());
        return toDto(conv);
    }

    @Transactional
    public MessageDto sendMessage(Long conversationId, MessageCreate request) {
        AppUser user = sessionAuth.requireUser();
        Conversation conv = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new ApiException(404, "Conversație negăsită."));
        assertParticipant(conv, user.getId());

        Message msg = new Message();
        msg.setSender(user);
        msg.setText(request.text().trim());
        conv.addMessage(msg);
        conversationRepository.save(conv);
        return MessageDto.from(msg);
    }

    private ConversationDto toDto(Conversation c) {
        List<Message> messages = messageRepository.findByConversationIdOrderBySentAtAsc(c.getId());
        MeetingSession session = meetingSessionRepository.findByConversationId(c.getId()).orElse(null);
        return ConversationDto.from(c, messages, session);
    }
}
