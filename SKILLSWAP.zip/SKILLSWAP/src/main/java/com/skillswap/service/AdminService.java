package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.ReportDto;
import com.skillswap.dto.UserProfileDto;
import com.skillswap.exception.ApiException;
import com.skillswap.model.AppUser;
import com.skillswap.model.UserRole;
import com.skillswap.repository.AppUserRepository;
import com.skillswap.repository.ReportRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminService {

    private final AppUserRepository userRepository;
    private final ReportRepository reportRepository;
    private final SessionAuth sessionAuth;

    public AdminService(AppUserRepository userRepository, ReportRepository reportRepository, SessionAuth sessionAuth) {
        this.userRepository = userRepository;
        this.reportRepository = reportRepository;
        this.sessionAuth = sessionAuth;
    }

    @Transactional(readOnly = true)
    public List<UserProfileDto> listUsers() {
        sessionAuth.requireAdmin();
        return userRepository.findByRoleNot(UserRole.ADMIN).stream()
                .map(UserProfileDto::from)
                .collect(Collectors.toList());
    }

    @Transactional
    public UserProfileDto toggleBlock(Long userId) {
        sessionAuth.requireAdmin();
        AppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException(404, "Utilizator negăsit."));
        user.setBlocked(!user.isBlocked());
        return UserProfileDto.from(userRepository.save(user));
    }

    @Transactional(readOnly = true)
    public List<ReportDto> listReports() {
        sessionAuth.requireAdmin();
        return reportRepository.findAllByOrderByIdDesc().stream()
                .map(ReportDto::from)
                .collect(Collectors.toList());
    }

    @Transactional
    public ReportDto resolveReport(Long id) {
        sessionAuth.requireAdmin();
        var report = reportRepository.findById(id)
                .orElseThrow(() -> new ApiException(404, "Raport negăsit."));
        report.setStatus("Rezolvat");
        return ReportDto.from(reportRepository.save(report));
    }
}
