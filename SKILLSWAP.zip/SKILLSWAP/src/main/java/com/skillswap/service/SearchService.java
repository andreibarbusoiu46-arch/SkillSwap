package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.SearchResponse;
import com.skillswap.dto.UserProfileDto;
import com.skillswap.model.AppUser;
import com.skillswap.model.UserRole;
import com.skillswap.repository.AppUserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SearchService {

    private final AppUserRepository userRepository;
    private final SessionAuth sessionAuth;

    public SearchService(AppUserRepository userRepository, SessionAuth sessionAuth) {
        this.userRepository = userRepository;
        this.sessionAuth = sessionAuth;
    }

    /**
     * Căutare indexată pe categorie/descriere aptitudini — țintă sub 2 secunde.
     */
    @Transactional(readOnly = true)
    public SearchResponse search(String query) {
        long start = System.currentTimeMillis();
        Long excludeId = sessionAuth.currentUserId();
        String q = query == null ? "" : query.trim();

        List<AppUser> users;
        if (q.isEmpty()) {
            users = userRepository.findAllActiveMembersWithSkills();
            if (excludeId != null) {
                users = users.stream().filter(u -> !u.getId().equals(excludeId)).collect(Collectors.toList());
            }
        } else {
            users = userRepository.searchActiveMembers(q, excludeId);
            users.forEach(u -> u.getSkills().size());
        }

        List<UserProfileDto> results = users.stream()
                .map(UserProfileDto::from)
                .collect(Collectors.toList());

        long elapsed = System.currentTimeMillis() - start;
        return new SearchResponse(results, elapsed);
    }
}
