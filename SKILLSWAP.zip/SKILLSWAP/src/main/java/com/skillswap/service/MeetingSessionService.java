package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.MeetingSessionDto;
import com.skillswap.dto.MeetingSessionRequest;
import com.skillswap.dto.MeetingSessionRespond;
import com.skillswap.exception.ApiException;
import com.skillswap.model.*;
import com.skillswap.repository.ConversationRepository;
import com.skillswap.repository.MeetingSessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MeetingSessionService {

    private final MeetingSessionRepository meetingSessionRepository;
    private final ConversationRepository conversationRepository;
    private final SessionAuth sessionAuth;

    public MeetingSessionService(
            MeetingSessionRepository meetingSessionRepository,
            ConversationRepository conversationRepository,
            SessionAuth sessionAuth) {
        this.meetingSessionRepository = meetingSessionRepository;
        this.conversationRepository = conversationRepository;
        this.sessionAuth = sessionAuth;
    }

    @Transactional
    public MeetingSessionDto schedule(MeetingSessionRequest request) {
        AppUser initiator = sessionAuth.requireUser();
        Conversation conv = conversationRepository.findById(request.conversationId())
                .orElseThrow(() -> new ApiException(404, "Conversație negăsită."));

        boolean participant = conv.getParticipants().stream()
                .anyMatch(p -> p.getId().equals(initiator.getId()));
        if (!participant) {
            throw new ApiException(403, "Nu poți programa pentru această conversație.");
        }

        if (conv.getSwapRequest() == null || conv.getSwapRequest().getStatus() != SwapRequestStatus.Accepted) {
            throw new ApiException(400, "Schimbul trebuie acceptat înainte de programare.");
        }

        AppUser guest = conv.getParticipants().stream()
                .filter(p -> !p.getId().equals(initiator.getId()))
                .findFirst()
                .orElseThrow(() -> new ApiException(400, "Partener negăsit."));

        MeetingSession session = meetingSessionRepository.findByConversationId(conv.getId())
                .orElse(new MeetingSession());

        session.setConversation(conv);
        session.setInitiator(initiator);
        session.setGuest(guest);
        session.setSessionDate(request.date());
        session.setSessionTime(request.time());
        session.setLocation(request.location().trim());
        session.setStatus(MeetingSessionStatus.IN_ASTEPTARE);
        conv.setMeetingSession(session);

        meetingSessionRepository.save(session);

        Message systemMsg = new Message();
        systemMsg.setSender(initiator);
        systemMsg.setText("Am programat o ședință pentru " + request.date() + " la " + request.time()
                + ". Locație: " + request.location().trim());
        conv.addMessage(systemMsg);
        conversationRepository.save(conv);

        return MeetingSessionDto.from(session);
    }

    @Transactional
    public MeetingSessionDto respond(Long id, MeetingSessionRespond request) {
        AppUser current = sessionAuth.requireUser();
        MeetingSession session = meetingSessionRepository.findById(id)
                .orElseThrow(() -> new ApiException(404, "Ședință negăsită."));

        if (!session.getGuest().getId().equals(current.getId())) {
            throw new ApiException(403, "Doar invitatul poate răspunde.");
        }
        if (session.getStatus() != MeetingSessionStatus.IN_ASTEPTARE) {
            throw new ApiException(400, "Ședința a fost deja procesată.");
        }

        session.setStatus(request.status());
        meetingSessionRepository.save(session);
        return MeetingSessionDto.from(session);
    }

    @Transactional(readOnly = true)
    public MeetingSessionDto byConversation(Long conversationId) {
        return meetingSessionRepository.findByConversationId(conversationId)
                .map(MeetingSessionDto::from)
                .orElse(null);
    }
}
