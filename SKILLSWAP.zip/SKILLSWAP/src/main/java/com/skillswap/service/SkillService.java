package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.SkillBrowseDto;
import com.skillswap.dto.SkillDto;
import com.skillswap.dto.SkillUpdateRequest;
import com.skillswap.dto.UserProfileDto;
import com.skillswap.exception.ApiException;
import com.skillswap.model.AppUser;
import com.skillswap.model.Skill;
import com.skillswap.model.SkillType;
import com.skillswap.repository.AppUserRepository;
import com.skillswap.repository.SkillRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SkillService {

    private final SkillRepository skillRepository;
    private final AppUserRepository userRepository;
    private final SessionAuth sessionAuth;

    public SkillService(SkillRepository skillRepository, AppUserRepository userRepository, SessionAuth sessionAuth) {
        this.skillRepository = skillRepository;
        this.userRepository = userRepository;
        this.sessionAuth = sessionAuth;
    }

    @Transactional(readOnly = true)
    public List<SkillBrowseDto> browseOfferedSkills() {
        return skillRepository.findAllOfferedSkillsWithUser().stream()
                .map(s -> new SkillBrowseDto(
                        s.getCategory(),
                        s.getDescription(),
                        UserProfileDto.from(s.getUser())
                ))
                .collect(Collectors.toList());
    }

    @Transactional
    public UserProfileDto updateMySkills(SkillUpdateRequest request) {
        AppUser user = sessionAuth.requireUser();
        user = userRepository.findById(user.getId()).orElseThrow();

        user.clearSkillsByType(SkillType.OFFERED);
        user.clearSkillsByType(SkillType.WANTED);

        String offeredCat = trim(request.offeredCategory());
        if (offeredCat != null && !offeredCat.isBlank()) {
            Skill offered = new Skill();
            offered.setCategory(offeredCat);
            offered.setDescription(trim(request.offeredDescription()));
            offered.setSkillType(SkillType.OFFERED);
            user.addSkill(offered);
        }

        String wantedCat = trim(request.wantedCategory());
        if (wantedCat != null && !wantedCat.isBlank()) {
            Skill wanted = new Skill();
            wanted.setCategory(wantedCat);
            wanted.setSkillType(SkillType.WANTED);
            user.addSkill(wanted);
        }

        userRepository.save(user);
        return UserProfileDto.from(user);
    }

    private String trim(String value) {
        return value == null ? null : value.trim();
    }
}
