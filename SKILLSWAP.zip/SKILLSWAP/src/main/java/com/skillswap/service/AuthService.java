package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.*;
import com.skillswap.exception.ApiException;
import com.skillswap.model.*;
import com.skillswap.repository.AppUserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class AuthService {

    private static final String[] AVATAR_COLORS = {
            "#0d9488", "#0f766e", "#14b8a6", "#0891b2", "#0e7490", "#115e59"
    };

    private final AppUserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final SessionAuth sessionAuth;

    public AuthService(AppUserRepository userRepository, PasswordEncoder passwordEncoder, SessionAuth sessionAuth) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.sessionAuth = sessionAuth;
    }

    @Transactional(readOnly = true)
    public UserProfileDto login(LoginRequest request, HttpSession session) {
        AppUser user = userRepository.findByEmail(request.email().trim().toLowerCase())
                .orElseThrow(() -> new ApiException(401, "Email sau parolă incorecte."));
        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new ApiException(401, "Email sau parolă incorecte.");
        }
        if (user.isBlocked()) {
            throw new ApiException(403, "Contul tău a fost blocat de administrator.");
        }
        sessionAuth.login(user, session);
        return UserProfileDto.from(user);
    }

    @Transactional
    public UserProfileDto register(RegisterRequest request, HttpSession session) {
        if (!request.termsAccepted()) {
            throw new ApiException(400, "Trebuie să accepți Termenii și Condițiile (GDPR).");
        }
        if (!request.password().equals(request.passwordConfirm())) {
            throw new ApiException(400, "Parolele nu coincid.");
        }
        String email = request.email().trim().toLowerCase();
        String username = request.username().trim();
        if (userRepository.existsByEmail(email)) {
            throw new ApiException(400, "Email-ul este deja înregistrat.");
        }
        if (userRepository.existsByUsername(username)) {
            throw new ApiException(400, "Numele de utilizator este deja folosit.");
        }

        AppUser user = new AppUser();
        user.setUsername(username);
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        user.setRole(UserRole.MEMBER);
        user.setDisplayName(username.replace("_", " "));
        user.setAvatarInitials(username.substring(0, Math.min(2, username.length())).toUpperCase());
        user.setAvatarColor(AVATAR_COLORS[new Random().nextInt(AVATAR_COLORS.length)]);
        userRepository.save(user);
        sessionAuth.login(user, session);
        return UserProfileDto.from(user);
    }

    public void logout(HttpSession session) {
        sessionAuth.logout(session);
    }

    @Transactional(readOnly = true)
    public UserProfileDto currentUser() {
        AppUser user = sessionAuth.requireUser();
        return UserProfileDto.from(userRepository.findByIdWithSkills(user.getId())
                .orElseThrow(() -> new ApiException(401, "Sesiune invalidă.")));
    }

    @Transactional(readOnly = true)
    public UserProfileDto getUserById(Long id) {
        AppUser user = userRepository.findByIdWithSkills(id)
                .orElseThrow(() -> new ApiException(404, "Utilizator negăsit."));
        if (user.getRole() == UserRole.ADMIN) {
            throw new ApiException(404, "Utilizator negăsit.");
        }
        return UserProfileDto.from(user);
    }

    @Transactional(readOnly = true)
    public List<UserProfileDto> listMembers() {
        return userRepository.findAllActiveMembersWithSkills().stream()
                .map(UserProfileDto::from)
                .collect(Collectors.toList());
    }
}
