package com.skillswap.service;

import com.skillswap.config.SessionAuth;
import com.skillswap.dto.SwapRequestCreate;
import com.skillswap.dto.SwapRequestDto;
import com.skillswap.dto.SwapRequestRespond;
import com.skillswap.exception.ApiException;
import com.skillswap.model.*;
import com.skillswap.repository.AppUserRepository;
import com.skillswap.repository.ConversationRepository;
import com.skillswap.repository.SwapRequestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class SwapRequestService {

    private final SwapRequestRepository swapRequestRepository;
    private final AppUserRepository userRepository;
    private final ConversationRepository conversationRepository;
    private final SessionAuth sessionAuth;

    public SwapRequestService(
            SwapRequestRepository swapRequestRepository,
            AppUserRepository userRepository,
            ConversationRepository conversationRepository,
            SessionAuth sessionAuth) {
        this.swapRequestRepository = swapRequestRepository;
        this.userRepository = userRepository;
        this.conversationRepository = conversationRepository;
        this.sessionAuth = sessionAuth;
    }

    @Transactional
    public SwapRequestDto create(SwapRequestCreate request) {
        AppUser from = sessionAuth.requireUser();
        if (from.getId().equals(request.toUserId())) {
            throw new ApiException(400, "Nu poți trimite o cerere către tine însuți.");
        }
        AppUser to = userRepository.findById(request.toUserId())
                .orElseThrow(() -> new ApiException(404, "Utilizator negăsit."));
        if (to.isBlocked() || to.getRole() == UserRole.ADMIN) {
            throw new ApiException(400, "Utilizator indisponibil.");
        }
        if (swapRequestRepository.existsByFromUserIdAndToUserIdAndStatus(
                from.getId(), to.getId(), SwapRequestStatus.Pending)) {
            throw new ApiException(400, "Există deja o cerere în așteptare.");
        }

        SwapRequest swap = new SwapRequest();
        swap.setFromUser(from);
        swap.setToUser(to);
        swap.setMessage(request.message().trim());
        swap.setStatus(SwapRequestStatus.Pending);
        swap.setCreatedAt(LocalDateTime.now());
        swapRequestRepository.save(swap);

        Conversation conv = new Conversation();
        Set<AppUser> participants = new HashSet<>();
        participants.add(from);
        participants.add(to);
        conv.setParticipants(participants);
        conv.setSwapRequest(swap);
        swap.setConversation(conv);

        Message first = new Message();
        first.setSender(from);
        first.setText(request.message().trim());
        conv.addMessage(first);

        conversationRepository.save(conv);

        return SwapRequestDto.from(swap);
    }

    @Transactional
    public SwapRequestDto respond(Long id, SwapRequestRespond request) {
        AppUser current = sessionAuth.requireUser();
        SwapRequest swap = swapRequestRepository.findById(id)
                .orElseThrow(() -> new ApiException(404, "Cerere negăsită."));
        if (!swap.getToUser().getId().equals(current.getId())) {
            throw new ApiException(403, "Nu poți răspunde la această cerere.");
        }
        if (swap.getStatus() != SwapRequestStatus.Pending) {
            throw new ApiException(400, "Cererea a fost deja procesată.");
        }
        if (request.status() == SwapRequestStatus.Pending) {
            throw new ApiException(400, "Status invalid.");
        }
        swap.setStatus(request.status());
        return SwapRequestDto.from(swapRequestRepository.save(swap));
    }

    @Transactional(readOnly = true)
    public List<SwapRequestDto> pendingForMe() {
        AppUser current = sessionAuth.requireUser();
        return swapRequestRepository.findByToUserIdAndStatus(current.getId(), SwapRequestStatus.Pending)
                .stream()
                .map(SwapRequestDto::from)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public SwapRequestDto findBetween(Long fromId, Long toId) {
        return swapRequestRepository.findByFromUserIdAndToUserId(fromId, toId)
                .map(SwapRequestDto::from)
                .orElse(null);
    }

    @Transactional(readOnly = true)
    public List<SwapRequestDto> allForAdmin() {
        sessionAuth.requireAdmin();
        return swapRequestRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(SwapRequestDto::from)
                .collect(Collectors.toList());
    }
}
