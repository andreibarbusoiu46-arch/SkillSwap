package com.skillswap.repository;

import com.skillswap.model.Skill;
import com.skillswap.model.SkillType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SkillRepository extends JpaRepository<Skill, Long> {

    List<Skill> findBySkillTypeAndUserBlockedFalseAndUserRoleNot(SkillType skillType, com.skillswap.model.UserRole role);

    @Query("SELECT s FROM Skill s JOIN FETCH s.user u WHERE s.skillType = com.skillswap.model.SkillType.OFFERED " +
           "AND u.blocked = false AND u.role <> com.skillswap.model.UserRole.ADMIN ORDER BY s.id DESC")
    List<Skill> findAllOfferedSkillsWithUser();
}
