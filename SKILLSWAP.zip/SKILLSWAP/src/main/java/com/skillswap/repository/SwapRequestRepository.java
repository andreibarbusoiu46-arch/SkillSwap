package com.skillswap.repository;

import com.skillswap.model.SwapRequest;
import com.skillswap.model.SwapRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SwapRequestRepository extends JpaRepository<SwapRequest, Long> {

    List<SwapRequest> findByToUserIdAndStatus(Long toUserId, SwapRequestStatus status);

    Optional<SwapRequest> findByFromUserIdAndToUserId(Long fromUserId, Long toUserId);

    boolean existsByFromUserIdAndToUserIdAndStatus(Long fromUserId, Long toUserId, SwapRequestStatus status);

    List<SwapRequest> findAllByOrderByCreatedAtDesc();
}
