package com.skillswap.repository;

import com.skillswap.model.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByEmail(String email);

    Optional<AppUser> findByUsername(String username);

    @Query("SELECT DISTINCT u FROM AppUser u LEFT JOIN FETCH u.skills WHERE u.id = :id")
    Optional<AppUser> findByIdWithSkills(@Param("id") Long id);

    @Query("SELECT DISTINCT u FROM AppUser u LEFT JOIN FETCH u.skills WHERE u.role <> com.skillswap.model.UserRole.ADMIN AND u.blocked = false")
    List<AppUser> findAllActiveMembersWithSkills();

    boolean existsByEmail(String email);

    boolean existsByUsername(String username);

    @Query("SELECT DISTINCT u FROM AppUser u LEFT JOIN FETCH u.skills s " +
           "WHERE u.role <> com.skillswap.model.UserRole.ADMIN AND u.blocked = false " +
           "AND (:query IS NULL OR :query = '' OR " +
           "LOWER(s.category) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(s.description) LIKE LOWER(CONCAT('%', :query, '%'))) " +
           "AND (:excludeId IS NULL OR u.id <> :excludeId)")
    List<AppUser> searchActiveMembers(@Param("query") String query, @Param("excludeId") Long excludeId);

    List<AppUser> findByRoleNot(com.skillswap.model.UserRole role);
}
