package com.skillswap.repository;

import com.skillswap.model.MeetingSession;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MeetingSessionRepository extends JpaRepository<MeetingSession, Long> {

    Optional<MeetingSession> findByConversationId(Long conversationId);
}
