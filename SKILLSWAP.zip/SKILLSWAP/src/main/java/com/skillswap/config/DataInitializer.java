package com.skillswap.config;

import com.skillswap.model.*;
import com.skillswap.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seed(
            AppUserRepository userRepository,
            SwapRequestRepository swapRequestRepository,
            ConversationRepository conversationRepository,
            MeetingSessionRepository meetingSessionRepository,
            ReportRepository reportRepository,
            PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.count() > 0) {
                return;
            }

            AppUser alex = member(userRepository, passwordEncoder,
                    "alex_dev", "alex@example.com", "pass123", "Alexandru Popa",
                    "Pasionat de tehnologie și programare web.", "AP", "#0d9488",
                    "Programare", "Python, React, Node.js — 5 ani experiență", "Design Grafic");

            AppUser maria = member(userRepository, passwordEncoder,
                    "maria_design", "maria@example.com", "pass123", "Maria Ionescu",
                    "Designer cu ochi pentru detalii și branding.", "MI", "#14b8a6",
                    "Design Grafic", "Figma, Adobe Suite, UI/UX, branding", "Fotografie");

            AppUser tudor = member(userRepository, passwordEncoder,
                    "tudor_foto", "tudor@example.com", "pass123", "Tudor Constantin",
                    "Fotograf freelancer cu echipament profesional.", "TC", "#0891b2",
                    "Fotografie", "Portret, produs, peisaj — calitate premium", "Marketing Digital");

            AppUser ioana = member(userRepository, passwordEncoder,
                    "ioana_mkt", "ioana@example.com", "pass123", "Ioana Dumitrescu",
                    "Specialist marketing cu 3 ani experiență.", "ID", "#0f766e",
                    "Marketing Digital", "SEO, Google Ads, social media, content", "Programare");

            AppUser dan = member(userRepository, passwordEncoder,
                    "dan_eng", "dan@example.com", "pass123", "Dan Marinescu",
                    "Profesor de engleză certificat CELTA.", "DM", "#115e59",
                    "Engleză", "Conversație, gramatică, pregătire IELTS/TOEFL", "Programare");

            AppUser admin = new AppUser();
            admin.setUsername("admin");
            admin.setEmail("admin@skillswap.ro");
            admin.setPasswordHash(passwordEncoder.encode("admin123"));
            admin.setRole(UserRole.ADMIN);
            admin.setDisplayName("Administrator");
            admin.setAvatarInitials("AD");
            admin.setAvatarColor("#0e7490");
            userRepository.save(admin);

            SwapRequest req1 = new SwapRequest();
            req1.setFromUser(alex);
            req1.setToUser(maria);
            req1.setMessage("Salut! Îți ofer ajutor cu programare web în schimbul unui logo pentru proiectul meu.");
            req1.setStatus(SwapRequestStatus.Pending);
            req1.setRequestDate(LocalDate.of(2025, 6, 10));
            swapRequestRepository.save(req1);

            Conversation conv1 = newConversation(req1, alex, maria);
            addMsg(conv1, alex, "Salut Maria! Am văzut că oferi design grafic.");
            addMsg(conv1, maria, "Da, bună! Cu ce te pot ajuta?");
            addMsg(conv1, alex, "Aș vrea să facem un swap — programare contra logo.");
            conversationRepository.save(conv1);

            SwapRequest req2 = new SwapRequest();
            req2.setFromUser(tudor);
            req2.setToUser(ioana);
            req2.setMessage("Bună! Pot face poze profesionale pentru portofoliu, aș vrea ajutor cu marketingul.");
            req2.setStatus(SwapRequestStatus.Accepted);
            req2.setRequestDate(LocalDate.of(2025, 6, 8));
            swapRequestRepository.save(req2);

            Conversation conv2 = newConversation(req2, tudor, ioana);
            addMsg(conv2, tudor, "Bună Ioana! Pot face poze profesionale pentru campania ta.");
            addMsg(conv2, ioana, "Super! Avem nevoie de poze pentru produse.");
            addMsg(conv2, tudor, "Perfect, stabilim detaliile.");
            conversationRepository.save(conv2);

            MeetingSession sess = new MeetingSession();
            sess.setConversation(conv2);
            sess.setInitiator(tudor);
            sess.setGuest(ioana);
            sess.setSessionDate(LocalDate.of(2025, 6, 22));
            sess.setSessionTime(LocalTime.of(14, 0));
            sess.setLocation("https://meet.google.com/abc-xyz");
            sess.setStatus(MeetingSessionStatus.IN_ASTEPTARE);
            conv2.setMeetingSession(sess);
            meetingSessionRepository.save(sess);

            Report rep = new Report();
            rep.setReporter(maria);
            rep.setReported(tudor);
            rep.setReason("Ofertă inadecvată în descriere");
            rep.setStatus("Nou");
            reportRepository.save(rep);
        };
    }

    private AppUser member(
            AppUserRepository repo,
            PasswordEncoder encoder,
            String username,
            String email,
            String password,
            String name,
            String bio,
            String initials,
            String color,
            String offeredCat,
            String offeredDesc,
            String wantedCat) {
        AppUser u = new AppUser();
        u.setUsername(username);
        u.setEmail(email);
        u.setPasswordHash(encoder.encode(password));
        u.setRole(UserRole.MEMBER);
        u.setDisplayName(name);
        u.setBio(bio);
        u.setAvatarInitials(initials);
        u.setAvatarColor(color);

        Skill offered = new Skill();
        offered.setCategory(offeredCat);
        offered.setDescription(offeredDesc);
        offered.setSkillType(SkillType.OFFERED);
        u.addSkill(offered);

        Skill wanted = new Skill();
        wanted.setCategory(wantedCat);
        wanted.setSkillType(SkillType.WANTED);
        u.addSkill(wanted);

        return repo.save(u);
    }

    private Conversation newConversation(SwapRequest req, AppUser u1, AppUser u2) {
        Conversation c = new Conversation();
        Set<AppUser> pts = new HashSet<>();
        pts.add(u1);
        pts.add(u2);
        c.setParticipants(pts);
        c.setSwapRequest(req);
        req.setConversation(c);
        return c;
    }

    private void addMsg(Conversation c, AppUser sender, String text) {
        Message m = new Message();
        m.setSender(sender);
        m.setText(text);
        c.addMessage(m);
    }
}
