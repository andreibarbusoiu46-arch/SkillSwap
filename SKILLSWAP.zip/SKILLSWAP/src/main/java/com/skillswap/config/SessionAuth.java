package com.skillswap.config;

import com.skillswap.exception.ApiException;
import com.skillswap.model.AppUser;
import com.skillswap.repository.AppUserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Component
public class SessionAuth {

    public static final String SESSION_USER_ID = "userId";

    private final AppUserRepository userRepository;

    public SessionAuth(AppUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void login(AppUser user, HttpSession session) {
        session.setAttribute(SESSION_USER_ID, user.getId());
    }

    public void logout(HttpSession session) {
        session.invalidate();
    }

    public AppUser requireUser() {
        Long id = currentUserId();
        if (id == null) {
            throw new ApiException(401, "Autentificare necesară.");
        }
        return userRepository.findById(id)
                .orElseThrow(() -> new ApiException(401, "Sesiune invalidă."));
    }

    public AppUser requireAdmin() {
        AppUser user = requireUser();
        if (user.getRole() != com.skillswap.model.UserRole.ADMIN) {
            throw new ApiException(403, "Acces interzis.");
        }
        return user;
    }

    public Long currentUserId() {
        HttpSession session = currentSession();
        if (session == null) {
            return null;
        }
        Object attr = session.getAttribute(SESSION_USER_ID);
        return attr instanceof Long ? (Long) attr : null;
    }

    private HttpSession currentSession() {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attrs == null) {
            return null;
        }
        HttpServletRequest request = attrs.getRequest();
        return request.getSession(false);
    }
}
